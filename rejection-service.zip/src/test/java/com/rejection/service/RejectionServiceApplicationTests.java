package com.rejection.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RejectionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
